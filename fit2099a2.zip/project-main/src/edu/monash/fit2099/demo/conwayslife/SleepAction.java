package edu.monash.fit2099.demo.conwayslife;

public class SleepAction {
}
