# FIT2099 Assignment (Semester 1, 2023)
# Elden Ring

## MA_Lab03Team02
Team members: Jun Rain Lim, Ong Jing Wei, Toh Xi Heng

## Contribution Log
https://docs.google.com/spreadsheets/d/1cLjWOEn0dRFFwnG08aGzGBJsx_xrxdUclkS16-VpBBg/edit?usp=sharing